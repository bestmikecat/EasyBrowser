package com.mycompany.myapp2;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.content.res.*;
import android.net.*;
import android.net.http.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout.*;
import android.widget.PopupMenu.*;

import android.view.View.OnClickListener;
import android.graphics.*;
import android.media.*;
import java.util.regex.*;



public class MainActivity extends Activity
{   private ImageButton bn;
	private AutoCompleteTextView et;
	private WebView wv;
    private ImageButton bt;
	private ImageButton ib;
	private ImageButton sp;
	private ProgressBar bar;
	private LinearLayout ll;
	private View vi;
	private LayoutInflater mLayoutInflater;
	
	
	
	//提示字符
	private String[] keys={"https://bestmike.ml","http://www.baidu.com","http://www.5566.net","http://www.google.com"};
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.main);
		wv=(WebView) findViewById(R.id.mainWebView1);
		et=(AutoCompleteTextView) findViewById(R.id.mainEditText1);
		bn=(ImageButton) findViewById(R.id.mainButton1);
		bt=(ImageButton) findViewById(R.id.topmainButton1);
		ib=(ImageButton) findViewById(R.id.mainButton2);
	    bar = (ProgressBar)findViewById(R.id.myProgressBar);
		ll=(LinearLayout) findViewById(R.id.mainLinearLayout);
		sp=(ImageButton) findViewById(R.id.stop);
		
		mLayoutInflater=LayoutInflater.from(this);
		
		
		wv.requestFocus();
	
	
		wv.loadUrl("http://www.5566.net");
		
		//控件动态修改
		if (Build.VERSION.SDK_INT == Build.VERSION_CODES.KITKAT) {
			LinearLayout.LayoutParams lp = (LayoutParams) et.getLayoutParams();
			lp.setMargins(0,35,0,0);
			et.setLayoutParams(lp);
			LinearLayout.LayoutParams lp2 = (LayoutParams) bn.getLayoutParams();
			lp2.setMargins(0,35,0,0);
			bn.setLayoutParams(lp2);
			LinearLayout.LayoutParams lp3 = (LayoutParams) bt.getLayoutParams();
			lp3.setMargins(0,35,0,0);
			bt.setLayoutParams(lp3);
			LinearLayout.LayoutParams lp4 = (LayoutParams) ib.getLayoutParams();
			lp4.setMargins(0,35,0,0);
			ib.setLayoutParams(lp4);
			LinearLayout.LayoutParams lp5 = (LayoutParams) sp.getLayoutParams();
			lp5.setMargins(0,35,0,0);
			sp.setLayoutParams(lp5);
		}

		
		ArrayAdapter<String> Adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,keys);
		et.setAdapter(Adapter);
		String ua3=getString(R.string.phone);
		//wv.getSettings().setUserAgentString(ua3);
		Toast.makeText(MainActivity.this,"欢迎进入浏览器(1.83)",Toast.LENGTH_LONG).show();
		
		
		
		//支持java
		wv.getSettings().setJavaScriptEnabled(true);
		wv.getSettings().setUseWideViewPort(true);
		wv.getSettings().setBuiltInZoomControls(true); 
		wv.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		wv.getSettings().setAllowFileAccess(true);
		//支持地图
		wv.getSettings().setDatabaseEnabled(true); 
		String dir = this.getApplicationContext().getDir("database", Context.MODE_PRIVATE).getPath();
		wv.getSettings().setGeolocationEnabled(true);
		wv.getSettings().setGeolocationDatabasePath(dir);
		wv.getSettings().setDomStorageEnabled(true);
		
		
	
		
		
		wv.setWebChromeClient(new WebChromeClient(){
			
			
				private View mCustomView;
				private WebChromeClient.CustomViewCallback mCustomViewCallback;
				private int mOriginalOrientation;
				private int mOriginalSystemUiVisibility;
			public void onHideCustomView() {
((FrameLayout) getWindow().getDecorView()).removeView(this.mCustomView);
this.mCustomView = null;
getWindow().getDecorView().setSystemUiVisibility(this.mOriginalSystemUiVisibility);
setRequestedOrientation(this.mOriginalOrientation);
		 	
this.mCustomViewCallback.onCustomViewHidden();
this.mCustomViewCallback = null;
setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
}
			
				public void onShowCustomView(View paramView, WebChromeClient.CustomViewCallback paramCustomViewCallback) {
				if (this.mCustomView != null) {
				onHideCustomView();
				return;
				}
				
				this.mCustomView = paramView;
			this.mOriginalSystemUiVisibility = getWindow().getDecorView().getSystemUiVisibility();
			this.mOriginalOrientation = getRequestedOrientation();
					setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
this.mCustomViewCallback = paramCustomViewCallback;
			((FrameLayout) getWindow()
.getDecorView())
.addView(this.mCustomView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
					  );
			}
			
			@Override
				public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback callback)
				{ callback.invoke(origin, true, false); super.onGeolocationPermissionsShowPrompt(origin, callback); } 
		        
				@Override
				public void onReceivedTitle(WebView view, String title) {          
					
					
					}      
					
				//处理alert弹出框，html 弹框的一种方式                     
				@Override
				public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
					Toast.makeText(MainActivity.this,"alert窗口",Toast.LENGTH_SHORT).show();
					AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
					builder.setMessage(message);
					
					builder.setNegativeButton("取消", new AlertDialog.OnClickListener()
					{
							@Override
							public void onClick(DialogInterface p1, int p2)
							{
							     result.cancel();
							}  
						});
						
					builder.setPositiveButton("确定", new AlertDialog.OnClickListener() 
					{
							@Override
							public void onClick(DialogInterface dialog, int which) {
								
								result.confirm();
							}
						});
						builder.show();
				        return true;
						}
				

				//处理confirm弹出框
				@Override
					
				public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult
										  result) {
					Toast.makeText(MainActivity.this,"confirm窗口",Toast.LENGTH_SHORT).show();
					return super.onJsPrompt(view, url, message,defaultValue, result);
					
				}

				//处理prompt弹出框
				@Override
				public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
					Toast.makeText(MainActivity.this,"prompt窗口",Toast.LENGTH_SHORT).show();
					return super.onJsConfirm(view, url, message, result);
				}
		
				
				@Override
				public void onProgressChanged(WebView view, int newProgress) {
					if (newProgress == 100) {
						bar.setVisibility(View.INVISIBLE);
					} else {
						
						et.setText( wv.getUrl());
						if (View.INVISIBLE == bar.getVisibility())
							{
							bar.setVisibility(View.VISIBLE);
						}
						bar.setProgress(newProgress);
					}
					super.onProgressChanged(view, newProgress);
				}
				
			});
		
		//缩放
		wv.getSettings().setSupportZoom(true);
		//支持https链接
		
		
		wv.setWebViewClient(new WebViewClient() {  
		
		        
			

		
				@Override    
				public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {    
					handler.proceed();    
				}    
			});  
			
		wv.setDownloadListener(new DownloadListener() {  

				@Override  
				public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {  
					

					Uri uri = Uri.parse(url);  
					Intent intent = new Intent(Intent.ACTION_VIEW, uri);  
					startActivity(intent);  
				}  
			});  
							
		wv.setWebViewClient(new WebViewClient()
			{
				public boolean shouldOverrideUrlLoading(WebView view,String url)
				{
					if (url == null) return false;

					try{
						if(!url.startsWith("http://") && !url.startsWith("https://")){
							final Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
							AlertDialog.Builder builder2=new AlertDialog.Builder(MainActivity.this);
							builder2.setTitle("网页提示");
							builder2.setMessage("网页申请打开外部应用");
							builder2.setCancelable(false);
							builder2.setPositiveButton("确定", new DialogInterface.OnClickListener()
								{
									@Override
									public void onClick(DialogInterface p1, int p2)
									{
										
	                                    startActivity(intent);
									
									
									}
								});
							builder2.setNegativeButton("取消", new DialogInterface.OnClickListener()
								{
									@Override
									public void onClick(DialogInterface p1, int p2)
									{
										p1.dismiss();
									}
								});
								builder2.show();
				
							return true;
						}
					}catch (Exception e){//防止crash (如果手机上没有安装处理某个scheme开头的url的APP, 会导致crash)
						return true;//没有安装该app时，返回true，表示拦截自定义链接，但不跳转，避免弹出上面的错误页面
					}

		
					//返回值是true的时候控制去WebView打开，为false调用系统浏览器或第三方浏览.
					if(Build.VERSION.SDK_INT < 26) {
						view.loadUrl(url);
						return true;
					} else {
						return false;
					}
				
             }
			 
                 }
		)	;
			
		bn.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					String a=et.getText().toString();
					if(!isHttpUrl("https://"+a))
					{  wv.loadUrl("http://"+a); }
					
						
					else{wv.loadUrl("https://m.baidu.com/s?from=1011440l&word="+a);
						
					 	}
						}
			});
		
		bt.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(final View p1)
				{
					PopupMenu popupMenu = new PopupMenu(MainActivity.this, p1);
					popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener(){

							@Override
							public boolean onMenuItemClick(final MenuItem item)
							{
								switch (item.getItemId()) {
									case R.id.exit:
										
										AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
										builder.setTitle("浏览器提示");
										builder.setMessage("确定退出？");
										builder.setIcon(R.drawable.ic_launcher);
										
										//按钮的实现方法
										builder.setPositiveButton("取消", new DialogInterface.OnClickListener()
											{
												@Override
												public void onClick(DialogInterface p1, int p2)
												{
													p1.dismiss();
												}
											});
										builder.setNegativeButton("确定", new DialogInterface.OnClickListener()
											{
												@Override
												public void onClick(DialogInterface p1, int p2)
												{   wv.clearCache(true);
													MainActivity.this.finish();
													wv.clearFormData();
													wv.clearHistory();
													
												}
											});
										builder.show();
										return true;
									case R.id.google:
										wv.loadUrl("https://www.google.com");
										return true;
									case R.id.set:
										wv.loadUrl("http://www.5566.net");
										
										
										return true;
									case R.id.account:
									
										wv.goForward();
										return true;	
									case R.id.noimage:
										wv.getSettings().setBlockNetworkImage(true);
										Toast.makeText(MainActivity.this,"极限省流模式已开启",Toast.LENGTH_SHORT).show();
										return true;
										
									case R.id.big:
										String ua2=getString(R.string.uasb);
										wv.getSettings().setUserAgentString(ua2);
										Toast.makeText(MainActivity.this,"浏览器ua已改为Symbian.",Toast.LENGTH_SHORT).show();
										return true;
									case R.id.small:
										String ua1=getString(R.string.ua);
										wv.getSettings().setUserAgentString(ua1);
										Toast.makeText(MainActivity.this,"浏览器ua已改为win10.",Toast.LENGTH_SHORT).show();
										return true;
									
									case R.id.phone:
										String ua3=getString(R.string.phone);
										wv.getSettings().setUserAgentString(ua3);
										Toast.makeText(MainActivity.this,"浏览器ua已改为android.",Toast.LENGTH_SHORT).show();
										return true;
									case R.id.dark:
										wv.setWebViewClient(new WebViewClient() {  
												@Override
												public void onPageCommitVisible(WebView view, String url) {
													if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {  
														wv.evaluateJavascript("document.body.style.backgroundColor=\"black\";document.body.style.color=\"white\";", null);  
													} else {  
														wv.loadUrl("javascript:document.body.style.backgroundColor=\"#black\";document.body.style.color=\"white\";");  
													}  
												};
											});
										return true;
									case R.id.about:
											
										
										AlertDialog.Builder builder1=new AlertDialog.Builder(MainActivity.this);
										
										vi=mLayoutInflater.inflate(R.layout.introduce,null);
										builder1.setTitle("关于应用");
										builder1.setView(vi);
										builder1.setIcon(R.drawable.ic_launcher);
										builder1.setCancelable(false);
										//按钮的实现方法
										builder1.setPositiveButton("确定", new DialogInterface.OnClickListener()
											{
												@Override
												public void onClick(DialogInterface p1, int p2)
												{
													p1.dismiss();
													
												}
											});
										builder1.setNeutralButton("打开作者网站",new DialogInterface.OnClickListener(){

												@Override
												public void onClick(DialogInterface p1, int p2)
												{
												  wv.loadUrl("https://bestmike.ml");

												}
											
										});
										builder1.show();
										return true;
									
								}
								
					
								return false;
							}

							
						});
					popupMenu.inflate(R.menu.menu);
					popupMenu.show();
				}
			});
			
		ib.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					wv.reload();
					
				}
			});
				
		sp.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					wv.stopLoading();
					Toast.makeText(MainActivity.this,"网页已停止加载！",Toast.LENGTH_SHORT).show();
				}
			});
		
					
		
	}
	
	

	public static boolean isHttpUrl(String urls) {
		
		boolean isUrl;
		String regex = "(((https|http)?://)?([a-z0-9]+[.])|(www.))"+
		"\\w+[.|\\/]([a-z0-9]{0,})?[[.]([a-z0-9]{0,})]+((/[\\S&&[^,;\u4E00-\u9FA5]]+)+)?([.][a-z0-9]{0,}+|/?)";
		Pattern pat = Pattern.compile(regex.trim());
        Matcher mat = pat.matcher(urls.trim());
        isUrl = mat.matches();
        return isUrl;
		
	}
	
	
	
	public void myClick(View view){Toast.makeText(MainActivity.this,et.getText().toString(),Toast.LENGTH_LONG).show();}
	
	@Override
	public void onConfigurationChanged(Configuration config) {
		super.onConfigurationChanged(config);
		switch (config.orientation) {
			case Configuration.ORIENTATION_LANDSCAPE:
				getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
				getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
				ll.setVisibility(View.GONE);
				bar.setVisibility(View.GONE);
				break;
			case Configuration.ORIENTATION_PORTRAIT:
				getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
				getWindow().addFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
				ll.setVisibility(View.VISIBLE);
				bar.setVisibility(View.VISIBLE);
				break;
		}
		
	}
	
	
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{//音量调节代码
		AudioManager audio = (AudioManager) getSystemService(Service.AUDIO_SERVICE);
		
		switch (keyCode) {
			case KeyEvent.KEYCODE_VOLUME_UP:
				audio.adjustStreamVolume(
					AudioManager.STREAM_MUSIC,
					AudioManager.ADJUST_RAISE,
					AudioManager.FLAG_PLAY_SOUND | AudioManager.FLAG_SHOW_UI);
				return true;
			case KeyEvent.KEYCODE_VOLUME_DOWN:
				audio.adjustStreamVolume(
					AudioManager.STREAM_MUSIC,
					AudioManager.ADJUST_LOWER,
					AudioManager.FLAG_PLAY_SOUND | AudioManager.FLAG_SHOW_UI);
				return true;
			default:
				break;
		}
		
		//退出应用代码
		
		if(keyCode==KeyEvent.KEYCODE_BACK)
		{
			if(wv.canGoBack()){wv.goBack();return true;}
			else{
				AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
				builder.setTitle("浏览器提示");
				builder.setMessage("确定退出？");
				builder.setIcon(R.drawable.ic_launcher);
				//按钮的实现方法
				builder.setPositiveButton("取消", new DialogInterface.OnClickListener()
					{
						@Override
						public void onClick(DialogInterface p1, int p2)
						{
							p1.dismiss();
						}
					});
				builder.setNegativeButton("确定", new DialogInterface.OnClickListener()
					{
						@Override
						public void onClick(DialogInterface p1, int p2)
						{ wv.clearCache(true);
							MainActivity.this.finish();
							wv.clearFormData();
							wv.clearHistory();
						}
					});
				builder.show();

				return true;}
		}return false;
	}
	
	
	@Override
	public void onPause() {
		super.onPause();
		wv.onPause();
	}

	@Override
	public void onResume() {
		super.onResume();
		wv.onResume();
	}

	@Override
	public void onBackPressed() {
		if (wv.canGoBack()) {
			wv.goBack();
			return;
		}
		super.onBackPressed();
	}

	@Override
	public void onDestroy() {
		wv.destroy();
		super.onDestroy();
		
	}
	
	
}
